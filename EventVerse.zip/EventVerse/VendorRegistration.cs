﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventVerse
{
    public partial class VendorRegistration : Form
    {
        private Form prev;
        public VendorRegistration(Form prev)
        {
            InitializeComponent();
            this.prev = prev;
        }

        private void VendorRegistration_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            prev.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
