﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace EventVerse
{
    public partial class AttendeeDownloadEticket : Form
    {
        private Form prev;
        public AttendeeDownloadEticket(Form prev)
        {
            InitializeComponent();
            this.prev = prev;

        }

        private void DownloadEticketattendee_Load(object sender, EventArgs e)
        {
            // Add columns to the ListView
            listView1.Columns.Add("Ticket ID", 100);
            listView1.Columns.Add("Event ID", 100);
            listView1.Columns.Add("Ticket Type", 150);
            listView1.Columns.Add("Price", 100);
            listView1.Columns.Add("Availability", 100);

            // Load data into the ListView
            LoadDataIntoListView();

        }

        private void LoadDataIntoListView()
        {
            string connectionString = "Data Source=DESKTOP-425ALTB\\SQLEXPRESS;Initial Catalog=EventVerse;Integrated Security=True";
            string query = "SELECT TicketID, EventID, TicketType, Price, Availability FROM TICKET";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        // Create a ListViewItem for each row
                        ListViewItem item = new ListViewItem(reader["TicketID"].ToString());
                        item.SubItems.Add(reader["EventID"].ToString());
                        item.SubItems.Add(reader["TicketType"].ToString());
                        item.SubItems.Add(reader["Price"].ToString());
                        item.SubItems.Add(reader["Availability"].ToString());

                        // Add the item to the ListView
                        listView1.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0) // Ensure an item is selected
            {
                // Get data from the selected row
                ListViewItem selectedItem = listView1.SelectedItems[0];
                string ticketID = selectedItem.SubItems[0].Text;
                string eventID = selectedItem.SubItems[1].Text;
                string ticketType = selectedItem.SubItems[2].Text;
                string price = selectedItem.SubItems[3].Text;
                string availability = selectedItem.SubItems[4].Text;

                // Create ticket content
                string ticketContent = $"Ticket ID: {ticketID}\nEvent ID: {eventID}\nTicket Type: {ticketType}\nPrice: {price}\nAvailability: {availability}";

                // Save file locally
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Text Files (*.txt)|*.txt",
                    FileName = $"Ticket_{ticketID}.txt"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog.FileName, ticketContent);
                    MessageBox.Show("Ticket downloaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a ticket to download.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            prev.Show();
            
        }
    }
}
