﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EventVerse
{
    public partial class AttendeeLoginForm : Form
    {
        private Form prev;
        public AttendeeLoginForm(Form prev)
        {
            InitializeComponent();
            this.prev = prev;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-425ALTB\\SQLEXPRESS;Initial Catalog=EventVerse;Integrated Security=True";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT UserID, Name FROM [USER] WHERE Email=@Email AND Password=@Password";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", textBox1.Text);
                        cmd.Parameters.AddWithValue("@Password", textBox2.Text);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Fetch UserID and Name
                                int userId = reader.GetInt32(0);
                                string userName = reader.GetString(1);

                                MessageBox.Show($"Welcome, {userName}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Pass UserID to the dashboard form
                                var dashboard = new AttendeeeventDashboard(userId,this);
                                dashboard.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Invalid email or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var registrationForm = new AttendeeRegistrationForm(this);
            registrationForm.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            prev.Show();
        }

        private void AttendeeLoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
