﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventVerse
{
    public partial class Feedback_Moderation : Form
    {
        private Form prev;
        public Feedback_Moderation(Form prev)
        {
            InitializeComponent();
            this.prev = prev;
        }

        private void Feedback_Moderation_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'eventverseOriginal.FEEDBACK' table. You can move, or remove it, as needed.
            this.fEEDBACKTableAdapter.Fill(this.eventverseOriginal.FEEDBACK);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            prev.Show();
        }
    }
}
