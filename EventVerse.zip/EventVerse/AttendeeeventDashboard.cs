﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventVerse
{
    public partial class AttendeeeventDashboard : Form
    {
        private int Userid;
        private Form prev;
        public AttendeeeventDashboard(int Userid,Form prev)
        {
            InitializeComponent();
            this.Userid = Userid;
            this.prev = prev;

        }
        private void LoadEvents()
        {
            string query = @"
                SELECT e.Title, e.StartDate, e.EndDate, e.Location, e.EventID, e.OrganizerID, e.CategoryID, e.Description
                FROM EVENT e"; // No joins or user filters, just fetching all events

            try
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-425ALTB\\SQLEXPRESS;Initial Catalog=EventVerse;Integrated Security=True"))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void eventDashboard_Load(object sender, EventArgs e)
        {
            LoadEvents();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var startup = new Attendeestartup();
            startup.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var eventsearh = new AttendeeEventSearch(Userid, this);
            eventsearh.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var personal = new Attendeemanagepersonal(Userid, this);
            personal.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var eventsearh = new Rate_events_Attendee(Userid,this);
            eventsearh.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var eventsearh = new AttendeeTickets(Userid,this);
            eventsearh.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            prev.Show();
        }
    }
    }
